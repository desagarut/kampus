<?php

$db['default']['hostname'] = 'localhost';
$db['default']['username'] = 'root';
$db['default']['password'] = '';
$db['default']['database'] = 'sim_sthgarut';

$db['default']['stricton'] = TRUE;
?>